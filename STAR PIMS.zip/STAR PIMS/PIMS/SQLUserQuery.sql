USE HMS_PIMS;

CREATE TABLE Users (
   id INT IDENTITY(1,1) PRIMARY KEY, -- Corrected for SQL Server
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    user_role VARCHAR(20) NOT NULL, -- VARCHAR for flexibility
    recovery_question VARCHAR(255),
    recovery_answer VARCHAR(255)
);
