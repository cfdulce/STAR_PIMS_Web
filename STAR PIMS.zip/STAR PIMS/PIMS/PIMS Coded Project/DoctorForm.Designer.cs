﻿namespace PIMS
{
    partial class DoctorForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DoctorForm));
            this.panel1 = new System.Windows.Forms.Panel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSearchPatient = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridPatients = new System.Windows.Forms.DataGridView();
            this.datePickerDOB = new System.Windows.Forms.DateTimePicker();
            this.btnRegisterPatient = new System.Windows.Forms.Button();
            this.btnViewPatients = new System.Windows.Forms.Button();
            this.btnViewPrescriptions = new System.Windows.Forms.Button();
            this.btnViewBilling = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridPatients)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel1.Controls.Add(this.flowLayoutPanel1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(781, 86);
            this.panel1.TabIndex = 0;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Location = new System.Drawing.Point(6, 142);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(6);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(433, 200);
            this.flowLayoutPanel1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 34F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(203, 13);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(391, 53);
            this.label1.TabIndex = 0;
            this.label1.Text = "Welcome, Doctor";
            // 
            // btnSearchPatient
            // 
            this.btnSearchPatient.BackColor = System.Drawing.Color.SteelBlue;
            this.btnSearchPatient.Font = new System.Drawing.Font("MS Reference Sans Serif", 7.87F, System.Drawing.FontStyle.Bold);
            this.btnSearchPatient.ForeColor = System.Drawing.Color.White;
            this.btnSearchPatient.Location = new System.Drawing.Point(560, 142);
            this.btnSearchPatient.Margin = new System.Windows.Forms.Padding(6);
            this.btnSearchPatient.Name = "btnSearchPatient";
            this.btnSearchPatient.Size = new System.Drawing.Size(144, 40);
            this.btnSearchPatient.TabIndex = 0;
            this.btnSearchPatient.Text = "Look Up Patient";
            this.btnSearchPatient.UseVisualStyleBackColor = false;
            this.btnSearchPatient.Click += new System.EventHandler(this.btnSearchPatient_Click);
            // 
            // txtSearch
            // 
            this.txtSearch.Font = new System.Drawing.Font("MS Reference Sans Serif", 7.87F);
            this.txtSearch.Location = new System.Drawing.Point(184, 140);
            this.txtSearch.Margin = new System.Windows.Forms.Padding(4);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(300, 20);
            this.txtSearch.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MS Reference Sans Serif", 7.87F);
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(181, 105);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "Search for Patient";
            // 
            // dataGridPatients
            // 
            this.dataGridPatients.BackgroundColor = System.Drawing.Color.White;
            this.dataGridPatients.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridPatients.Location = new System.Drawing.Point(175, 253);
            this.dataGridPatients.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridPatients.Name = "dataGridPatients";
            this.dataGridPatients.RowHeadersWidth = 82;
            this.dataGridPatients.RowTemplate.Height = 33;
            this.dataGridPatients.Size = new System.Drawing.Size(557, 167);
            this.dataGridPatients.TabIndex = 4;
            // 
            // datePickerDOB
            // 
            this.datePickerDOB.CustomFormat = "yyyy/MM/dd";
            this.datePickerDOB.Font = new System.Drawing.Font("MS Reference Sans Serif", 7.87F);
            this.datePickerDOB.Location = new System.Drawing.Point(184, 189);
            this.datePickerDOB.Margin = new System.Windows.Forms.Padding(4);
            this.datePickerDOB.Name = "datePickerDOB";
            this.datePickerDOB.Size = new System.Drawing.Size(300, 20);
            this.datePickerDOB.TabIndex = 5;
            // 
            // btnRegisterPatient
            // 
            this.btnRegisterPatient.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnRegisterPatient.Font = new System.Drawing.Font("MS Reference Sans Serif", 7.87F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegisterPatient.ForeColor = System.Drawing.Color.White;
            this.btnRegisterPatient.Location = new System.Drawing.Point(24, 125);
            this.btnRegisterPatient.Margin = new System.Windows.Forms.Padding(6);
            this.btnRegisterPatient.Name = "btnRegisterPatient";
            this.btnRegisterPatient.Size = new System.Drawing.Size(109, 41);
            this.btnRegisterPatient.TabIndex = 12;
            this.btnRegisterPatient.Text = "Register Patient";
            this.btnRegisterPatient.UseVisualStyleBackColor = false;
            this.btnRegisterPatient.Click += new System.EventHandler(this.btnRegisterPatient_Click_1);
            // 
            // btnViewPatients
            // 
            this.btnViewPatients.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnViewPatients.Font = new System.Drawing.Font("MS Reference Sans Serif", 7.87F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewPatients.ForeColor = System.Drawing.Color.White;
            this.btnViewPatients.Location = new System.Drawing.Point(24, 196);
            this.btnViewPatients.Margin = new System.Windows.Forms.Padding(6);
            this.btnViewPatients.Name = "btnViewPatients";
            this.btnViewPatients.Size = new System.Drawing.Size(109, 37);
            this.btnViewPatients.TabIndex = 9;
            this.btnViewPatients.Text = "View Patient";
            this.btnViewPatients.UseVisualStyleBackColor = false;
            this.btnViewPatients.Click += new System.EventHandler(this.btnViewPatients_Click);
            // 
            // btnViewPrescriptions
            // 
            this.btnViewPrescriptions.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnViewPrescriptions.Font = new System.Drawing.Font("MS Reference Sans Serif", 7.87F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewPrescriptions.ForeColor = System.Drawing.Color.White;
            this.btnViewPrescriptions.Location = new System.Drawing.Point(24, 336);
            this.btnViewPrescriptions.Name = "btnViewPrescriptions";
            this.btnViewPrescriptions.Size = new System.Drawing.Size(109, 39);
            this.btnViewPrescriptions.TabIndex = 11;
            this.btnViewPrescriptions.Text = "View Prescriptions";
            this.btnViewPrescriptions.UseVisualStyleBackColor = false;
            this.btnViewPrescriptions.Click += new System.EventHandler(this.btnViewPrescriptions_Click_1);
            // 
            // btnViewBilling
            // 
            this.btnViewBilling.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnViewBilling.Font = new System.Drawing.Font("MS Reference Sans Serif", 7.87F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewBilling.ForeColor = System.Drawing.Color.White;
            this.btnViewBilling.Location = new System.Drawing.Point(24, 269);
            this.btnViewBilling.Name = "btnViewBilling";
            this.btnViewBilling.Size = new System.Drawing.Size(109, 37);
            this.btnViewBilling.TabIndex = 10;
            this.btnViewBilling.Text = "View Billing";
            this.btnViewBilling.UseVisualStyleBackColor = false;
            this.btnViewBilling.Click += new System.EventHandler(this.btnViewBilling_Click_1);
            // 
            // DoctorForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackgroundImage = global::PIMS.Properties.Resources.bkcg_color;
            this.ClientSize = new System.Drawing.Size(781, 451);
            this.Controls.Add(this.btnRegisterPatient);
            this.Controls.Add(this.btnViewPatients);
            this.Controls.Add(this.btnViewPrescriptions);
            this.Controls.Add(this.btnViewBilling);
            this.Controls.Add(this.datePickerDOB);
            this.Controls.Add(this.dataGridPatients);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.btnSearchPatient);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("MS Reference Sans Serif", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "DoctorForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Doctor Dashboard";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridPatients)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button btnSearchPatient;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridPatients;
        private System.Windows.Forms.DateTimePicker datePickerDOB;
        private System.Windows.Forms.Button btnRegisterPatient;
        private System.Windows.Forms.Button btnViewPatients;
        private System.Windows.Forms.Button btnViewPrescriptions;
        private System.Windows.Forms.Button btnViewBilling;
    }
}