﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace PIMS
{
    public partial class RegisterPatientForm : Form
    {
        // Connection string to establish a connection with the SQL Server database
        private string connectionString = @"Server=.\SQLEXPRESS;Database=HMS_PIMS;Trusted_Connection=True;";

        // Constructor for the form, initializes UI components
        public RegisterPatientForm()
        {
            InitializeComponent();
        }

        // Handles the button click event for registering a patient
        private void btnRegisterPatient_Click(object sender, EventArgs e)
        {
            // Retrieve patient information from input fields
            string patientName = txtPatientName.Text;  // Gets patient's full name
            string dob = datePickerDOB.Value.ToString("yyyy-MM-dd");  // Converts selected date to proper format
            string age = txtAge.Text;  // Gets patient's age
            string height = txtHeight.Text;  // Gets patient's height
            string weight = txtWeight.Text;  // Gets patient's weight

            // Insert the patient's information into the database
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "INSERT INTO Patients (name, dob, age, height, weight) VALUES (@name, @dob, @age, @height, @weight)";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    // Add parameters to prevent SQL injection and securely insert data
                    cmd.Parameters.AddWithValue("@name", patientName);
                    cmd.Parameters.AddWithValue("@dob", dob);
                    cmd.Parameters.AddWithValue("@age", age);
                    cmd.Parameters.AddWithValue("@height", height);
                    cmd.Parameters.AddWithValue("@weight", weight);

                    cmd.ExecuteNonQuery();  // Execute the SQL command to insert the data
                }
            }

            // Show success message along with generated login credentials
            MessageBox.Show("Patient registered successfully!");
        }
    }
}
