﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMS
{
    // Represents the Doctor's dashboard interface, allowing interaction with patient data.
    
    public partial class DoctorForm : Form
    {
        // Database connection string for local SQL Server instance
        private string connectionString = @"Server=.\SQLEXPRESS;Database=HMS_PIMS;Trusted_Connection=True;";
        private string doctorId; // Stores the logged-in doctor’s ID

        // Initializes the DoctorForm with the authenticated doctor's ID.
        public DoctorForm(string doctorId)
        {
            InitializeComponent(); // Loads UI components
            this.doctorId = doctorId; // Sets doctor ID for session
        }

        // Default constructor (not actively used)
        public DoctorForm()
        {
        }

        // Searches for patients by name and date of birth (DOB).
        private void btnSearchPatient_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open(); // Establish database connection

                // SQL query to search patients based on name and DOB
                string query = "SELECT id, name, age, diagnosis FROM Patients WHERE name LIKE @search AND dob=@dob";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@search", "%" + txtSearch.Text.Trim() + "%"); // Supports partial matches
                    cmd.Parameters.AddWithValue("@dob", datePickerDOB.Value.ToString("yyyy-MM-dd")); // Formats date correctly

                    SqlDataReader reader = cmd.ExecuteReader(); // Executes query

                    // Load query results into a DataTable
                    DataTable dt = new DataTable();
                    dt.Load(reader);

                    if (dt.Rows.Count > 0)
                    {
                        dataGridPatients.DataSource = dt; // Displays results in UI grid
                    }
                    else
                    {
                        MessageBox.Show("No patient found with the given details. Please check the name and date of birth."); // Displays alert
                    }
                }
            }
        }

        // Opens the patient registration form for adding new patients.
        private void btnRegisterPatient_Click_1(object sender, EventArgs e)
        {
            RegisterPatientForm registerForm = new RegisterPatientForm();
            registerForm.Show(); // Displays the registration form
        }

        // Opens detailed patient information for the selected patient.
        private void btnViewPatients_Click(object sender, EventArgs e)
        {
            if (dataGridPatients.SelectedRows.Count > 0) // Ensures a patient is selected
            {
                // Retrieves the selected patient's ID
                string patientId = dataGridPatients.SelectedRows[0].Cells["id"].Value.ToString();

                ViewPatientForm patientForm = new ViewPatientForm(patientId);
                patientForm.Show(); // Opens patient details form
            }
            else
            {
                MessageBox.Show("Please select a patient."); // Alerts user if no selection is made
            }
        }

        // Opens the billing details for the selected patient.
        private void btnViewBilling_Click_1(object sender, EventArgs e)
        {
            if (dataGridPatients.SelectedRows.Count > 0) // Ensures a patient is selected
            {
                string patientId = dataGridPatients.SelectedRows[0].Cells["id"].Value.ToString();

                BillingForm billingForm = new BillingForm(patientId);
                billingForm.Show(); // Opens billing interface
            }
            else
            {
                MessageBox.Show("Please select a patient."); // Alerts user if no selection is made
            }
        }

        // Opens the prescription details for the selected patient.
        private void btnViewPrescriptions_Click_1(object sender, EventArgs e)
        {
            if (dataGridPatients.SelectedRows.Count > 0) // Ensures a patient is selected
            {
                string patientId = dataGridPatients.SelectedRows[0].Cells["id"].Value.ToString();

                PrescriptionForm prescriptionForm = new PrescriptionForm(patientId);
                prescriptionForm.Show(); // Opens prescription details
            }
            else
            {
                MessageBox.Show("Please select a patient."); // Alerts user if no selection is made
            }
        }
    }
}
