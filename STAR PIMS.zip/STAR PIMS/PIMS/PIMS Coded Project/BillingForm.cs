﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace PIMS
{
    public partial class BillingForm : Form
    {
        // Stores the patient's ID
        private string patientId;

        // Connection string to the SQL Server database
        private string connectionString = @"Server=.\SQLEXPRESS;Database=HMS_PIMS;Trusted_Connection=True;";

        // Constructor for the billing form, initializes the patient ID and loads billing data
        public BillingForm(string patientId)
        {
            InitializeComponent();  // Initializes form components
            this.patientId = patientId;  // Stores the patient ID passed as a parameter
            LoadBillingData();  // Loads the billing records related to this patient
        }

        // Loads billing data for the given patient from the database and displays it in the data grid
        private void LoadBillingData()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT id, total_amount, status, payment_date, description, due_date FROM Billing WHERE patient_id=@patientId";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@patientId", patientId); // Passing patientId as parameter

                    SqlDataReader reader = cmd.ExecuteReader();
                    DataTable dt = new DataTable();
                    dt.Load(reader);  // Loads the retrieved data into a DataTable

                    dataGridBilling.DataSource = dt; // Displays the data in a grid on the form
                }
            }
        }

        // Handles the click event for generating a new bill
        private void btnGenerateBill_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "INSERT INTO Billing (patient_id, total_amount, status, description, due_date) VALUES (@patientId, @amount, 'Pending', @description, @dueDate)";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@patientId", patientId);
                    cmd.Parameters.AddWithValue("@amount", txtAmount.Text);
                    cmd.Parameters.AddWithValue("@description", txtDescription.Text); // Description of what the bill is for
                    cmd.Parameters.AddWithValue("@dueDate", datePickerDueDate.Value.ToString("yyyy-MM-dd")); // Due date for payment

                    cmd.ExecuteNonQuery();
                }
            }

            MessageBox.Show("Bill generated successfully!");
            LoadBillingData();
        }

        // Handles the click event for marking a bill as paid
        private void btnMarkAsPaid_Click(object sender, EventArgs e)
        {
            if (dataGridBilling.SelectedRows.Count > 0)  // Checks if a row is selected
            {
                int billId = Convert.ToInt32(dataGridBilling.SelectedRows[0].Cells["id"].Value);  // Retrieves the selected bill ID

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "UPDATE Billing SET status='Paid', payment_date=GETDATE() WHERE id=@billId";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@billId", billId); // Adds bill ID to the SQL command
                        cmd.ExecuteNonQuery();  // Executes the UPDATE command
                    }
                }

                MessageBox.Show("Bill marked as paid!"); // Display confirmation
                LoadBillingData();  // Refresh billing data
            }
            else
            {
                MessageBox.Show("Please select a bill to mark as paid."); // Show error if no row is selected
            }
        }

        // Handles the click event for closing the form
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close(); // Closes the billing form
        }
    }
}
