﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMS
{
    public partial class ViewPatientForm : Form
    {
        // Stores the patient's ID to identify the record in the database
        private string patientId;

        // Connection string to connect to the SQL Server database
        private string connectionString = @"Server=.\SQLEXPRESS;Database=HMS_PIMS;Trusted_Connection=True;";
        // Constructor for the form, initializes UI components and loads patient data
        public ViewPatientForm(string patientId)
        {
            InitializeComponent();
            this.patientId = patientId; // Store patient ID
            LoadPatientData(); // Load patient information upon form creation
        }

        // Loads patient data from the database and displays it in the relevant text fields
        private void LoadPatientData()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT name, age, height, weight, diagnosis, treatment, medical_history FROM Patients WHERE id = @patientId";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@patientId", patientId);
                        SqlDataReader reader = cmd.ExecuteReader();

                        if (reader.Read())
                        {
                            txtPatientName.Text = reader["name"].ToString();
                            txtPatientAge.Text = reader["age"].ToString();
                            txtPatientHeight.Text = reader["height"].ToString();
                            txtPatientWeight.Text = reader["weight"].ToString();
                            txtDiagnosis.Text = reader["diagnosis"].ToString();
                            txtTreatment.Text = reader["treatment"].ToString();
                            txtMedicalHistory.Text = reader["medical_history"].ToString();
                        }
                        else
                        {
                            MessageBox.Show("No patient records found.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading patient data: " + ex.Message);
            }
        }

        // Handles the event for saving updated patient details (diagnosis, treatment, history)
        private void btnSaveDiagnosis_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "UPDATE Patients SET height=@height, weight=@weight, diagnosis=@diagnosis, treatment=@treatment, medical_history=@history WHERE id=@patientId";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@height", txtPatientHeight.Text);
                        cmd.Parameters.AddWithValue("@weight", txtPatientWeight.Text);
                        cmd.Parameters.AddWithValue("@diagnosis", txtDiagnosis.Text);
                        cmd.Parameters.AddWithValue("@treatment", txtTreatment.Text);
                        cmd.Parameters.AddWithValue("@history", txtMedicalHistory.Text);
                        cmd.Parameters.AddWithValue("@patientId", patientId);

                        cmd.ExecuteNonQuery(); // Execute the update query
                    }
                }
                MessageBox.Show("Patient details updated successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving patient data: " + ex.Message);
            }
        }

        // Handles the event for closing the form and returning to the doctor dashboard
        private void btnClose_Click(object sender, EventArgs e)
        {
            try
            {
                this.Hide(); // Hide current patient form

                DoctorForm doctorDashboard = Application.OpenForms.OfType<DoctorForm>().FirstOrDefault();

                if (doctorDashboard != null)
                {
                    doctorDashboard.Show(); // Show the existing DoctorForm instead of opening a new one
                }
                else
                {
                    MessageBox.Show("Doctor Dashboard not found. Please restart the application.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error returning to the dashboard: " + ex.Message);
            }
        }
    }
}
