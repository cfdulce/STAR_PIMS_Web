﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace PIMS
{
    public partial class PrescriptionForm : Form
    {
        // Stores the patient's ID for identifying their prescriptions
        private string patientId;

        // Connection string to the SQL Server database
        private string connectionString = @"Server=.\SQLEXPRESS;Database=HMS_PIMS;Trusted_Connection=True;";

        // Constructor initializes the form and loads prescriptions for the given patient
        public PrescriptionForm(string patientId)
        {
            InitializeComponent();
            this.patientId = patientId; // Store patient ID
            LoadPrescriptions(); // Load prescriptions on form startup
        }

        // Loads prescriptions from the database and displays them in a data grid
        private void LoadPrescriptions()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT id, medication, dosage, refill_available, requested_date FROM Prescriptions WHERE patient_id=@patientId";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@patientId", patientId); // Bind patient ID to query
                        SqlDataReader reader = cmd.ExecuteReader();

                        DataTable dt = new DataTable();
                        dt.Load(reader); // Load results into a DataTable

                        dataGridPrescriptions.DataSource = dt; // Populate the data grid with prescription data
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading prescriptions: " + ex.Message);
            }
        }

        // Handles the event for adding a new prescription
        private void btnAddPrescription_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "INSERT INTO Prescriptions (patient_id, medication, dosage, refill_available, doctor_notes) VALUES (@patientId, @medication, @dosage, @refill, @notes)";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        // Add prescription details from form inputs
                        cmd.Parameters.AddWithValue("@patientId", patientId);
                        cmd.Parameters.AddWithValue("@medication", txtMedication.Text);
                        cmd.Parameters.AddWithValue("@dosage", txtDosage.Text);
                        cmd.Parameters.AddWithValue("@refill", chkRefillAvailable.Checked);
                        cmd.Parameters.AddWithValue("@notes", txtDoctorNotes.Text);

                        cmd.ExecuteNonQuery(); // Execute the INSERT query
                    }
                }
                MessageBox.Show("Prescription added successfully!");
                LoadPrescriptions(); // Refresh the prescription list
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding prescription: " + ex.Message);
            }
        }

        // Handles the event for refilling a prescription
        private void btnRefillPrescription_Click(object sender, EventArgs e)
        {
            if (dataGridPrescriptions.SelectedRows.Count > 0) // Ensure a row is selected
            {
                int prescriptionId = Convert.ToInt32(dataGridPrescriptions.SelectedRows[0].Cells["id"].Value); // Get selected prescription ID

                try
                {
                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        conn.Open();
                        string query = "UPDATE Prescriptions SET requested_date = GETDATE() WHERE id=@prescriptionId AND refill_available=1";

                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@prescriptionId", prescriptionId); // Bind prescription ID
                            cmd.ExecuteNonQuery(); // Execute the UPDATE query
                        }
                    }
                    MessageBox.Show("Prescription refilled successfully!");
                    LoadPrescriptions(); // Refresh prescription list
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error refilling prescription: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Select a prescription to refill."); // Alert if no selection was made
            }
        }

        // Handles the event for closing the form and returning to the doctor dashboard
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close(); // Close the prescription form
            DoctorForm doctorDashboard = new DoctorForm(); // Open doctor dashboard
            doctorDashboard.Show();
        }
    }
}
