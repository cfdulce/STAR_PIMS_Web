﻿namespace PIMS
{
    partial class PrescriptionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PrescriptionForm));
            this.dataGridPrescriptions = new System.Windows.Forms.DataGridView();
            this.txtMedication = new System.Windows.Forms.TextBox();
            this.txtDosage = new System.Windows.Forms.TextBox();
            this.chkRefillAvailable = new System.Windows.Forms.CheckBox();
            this.btnAddPrescription = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtDoctorNotes = new System.Windows.Forms.RichTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridPrescriptions)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridPrescriptions
            // 
            this.dataGridPrescriptions.BackgroundColor = System.Drawing.Color.White;
            this.dataGridPrescriptions.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridPrescriptions.Location = new System.Drawing.Point(31, 287);
            this.dataGridPrescriptions.Name = "dataGridPrescriptions";
            this.dataGridPrescriptions.RowHeadersWidth = 82;
            this.dataGridPrescriptions.RowTemplate.Height = 33;
            this.dataGridPrescriptions.Size = new System.Drawing.Size(506, 145);
            this.dataGridPrescriptions.TabIndex = 0;
            // 
            // txtMedication
            // 
            this.txtMedication.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.87F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMedication.Location = new System.Drawing.Point(128, 155);
            this.txtMedication.Name = "txtMedication";
            this.txtMedication.Size = new System.Drawing.Size(409, 19);
            this.txtMedication.TabIndex = 1;
            // 
            // txtDosage
            // 
            this.txtDosage.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.87F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDosage.Location = new System.Drawing.Point(128, 209);
            this.txtDosage.Name = "txtDosage";
            this.txtDosage.Size = new System.Drawing.Size(409, 19);
            this.txtDosage.TabIndex = 2;
            // 
            // chkRefillAvailable
            // 
            this.chkRefillAvailable.AutoSize = true;
            this.chkRefillAvailable.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.87F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkRefillAvailable.Location = new System.Drawing.Point(128, 253);
            this.chkRefillAvailable.Name = "chkRefillAvailable";
            this.chkRefillAvailable.Size = new System.Drawing.Size(95, 17);
            this.chkRefillAvailable.TabIndex = 3;
            this.chkRefillAvailable.Text = "Refill Available";
            this.chkRefillAvailable.UseVisualStyleBackColor = true;
            // 
            // btnAddPrescription
            // 
            this.btnAddPrescription.BackColor = System.Drawing.Color.SteelBlue;
            this.btnAddPrescription.Font = new System.Drawing.Font("MS Reference Sans Serif", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddPrescription.ForeColor = System.Drawing.Color.White;
            this.btnAddPrescription.Location = new System.Drawing.Point(31, 477);
            this.btnAddPrescription.Name = "btnAddPrescription";
            this.btnAddPrescription.Size = new System.Drawing.Size(119, 50);
            this.btnAddPrescription.TabIndex = 4;
            this.btnAddPrescription.Text = "Add Prescription";
            this.btnAddPrescription.UseVisualStyleBackColor = false;
            this.btnAddPrescription.Click += new System.EventHandler(this.btnAddPrescription_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.87F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(37, 158);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Medication";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.87F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(37, 209);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Dosage";
            // 
            // txtDoctorNotes
            // 
            this.txtDoctorNotes.Location = new System.Drawing.Point(213, 488);
            this.txtDoctorNotes.Name = "txtDoctorNotes";
            this.txtDoctorNotes.Size = new System.Drawing.Size(324, 93);
            this.txtDoctorNotes.TabIndex = 8;
            this.txtDoctorNotes.Text = "";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(210, 463);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 15);
            this.label3.TabIndex = 9;
            this.label3.Text = "Doctor Notes";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel1.Controls.Add(this.label4);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(579, 124);
            this.panel1.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 34F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(65, 40);
            this.label4.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(444, 53);
            this.label4.TabIndex = 1;
            this.label4.Text = "Patient Prescription";
            // 
            // PrescriptionForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackgroundImage = global::PIMS.Properties.Resources.bkcg_color;
            this.ClientSize = new System.Drawing.Size(579, 621);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtDoctorNotes);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnAddPrescription);
            this.Controls.Add(this.chkRefillAvailable);
            this.Controls.Add(this.txtDosage);
            this.Controls.Add(this.txtMedication);
            this.Controls.Add(this.dataGridPrescriptions);
            this.Font = new System.Drawing.Font("MS Reference Sans Serif", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "PrescriptionForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Prescriptions";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridPrescriptions)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridPrescriptions;
        private System.Windows.Forms.TextBox txtMedication;
        private System.Windows.Forms.TextBox txtDosage;
        private System.Windows.Forms.CheckBox chkRefillAvailable;
        private System.Windows.Forms.Button btnAddPrescription;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RichTextBox txtDoctorNotes;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
    }
}