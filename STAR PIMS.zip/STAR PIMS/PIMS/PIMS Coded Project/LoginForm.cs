﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;
using BCrypt.Net;

namespace PIMS
{
    public partial class Login : Form
    {
        private string connectionString = @"Server=.\SQLEXPRESS;Database=HMS_PIMS;Trusted_Connection=True;";

        public Login()
        {
            InitializeComponent();
            InitializeUI();
        }

        private void InitializeUI()
        {
            label3.Visible = false;
            label4.Visible = false;
            label5.Visible = false;
            label6.Visible = false;

            txtEmail.Visible = false;
            cmbRecoveryQuestion.Visible = false;
            txtRecoveryAnswer.Visible = false;
            txtNewPassword.Visible = false;
            btnConfirmRecovery.Visible = false;

            cmbRecoveryQuestion.Items.AddRange(new object[]
            {
                "What is your mother's maiden name?",
                "What was the name of your first pet?",
                "What is the name of the city where you were born?",
                "What was your first car?",
                "What is your favorite childhood book?"
            });

            cmbRecoveryQuestion.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbRecoveryQuestion.SelectedIndex = 0;
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT id, password_hash FROM Users WHERE username=@username AND user_role='Doctor'";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@username", username);
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        string storedHash = reader["password_hash"].ToString();
                        string doctorId = reader["id"].ToString();

                        if (BCrypt.Net.BCrypt.Verify(password, storedHash))
                        {
                            MessageBox.Show("Login successful! Redirecting to Doctor Dashboard.");
                            DoctorForm doctorDashboard = new DoctorForm(doctorId);
                            doctorDashboard.Show();
                            this.Hide();
                        }
                        else
                        {
                            MessageBox.Show("Incorrect password.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Doctor not found.");
                    }
                }
            }
        }

        private void btnRecoverPassword_Click(object sender, EventArgs e)
        {
            label3.Visible = true;
            label4.Visible = true;
            label5.Visible = true;
            label6.Visible = true;

            txtEmail.Visible = true;
            cmbRecoveryQuestion.Visible = true;
            txtRecoveryAnswer.Visible = true;
            txtNewPassword.Visible = true;
            btnConfirmRecovery.Visible = true;
        }

        private void btnSignIn_Click_1(object sender, EventArgs e)
        {
            string username = txtNewUsername.Text;
            string password = txtNewUserPassword.Text;
            string email = txtNewEmail.Text;
            string recoveryQuestion = cmbRecoveryQuestion.SelectedItem.ToString();
            string recoveryAnswer = txtNewRecoveryAnswer.Text;

            string hashedPassword = BCrypt.Net.BCrypt.HashPassword(password);
            string hashedAnswer = BCrypt.Net.BCrypt.HashPassword(recoveryAnswer);

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "INSERT INTO Users (username, password_hash, email, user_role, recovery_question, recovery_answer) VALUES (@username, @password, @email, 'Doctor', @question, @answer)";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@username", username);
                    cmd.Parameters.AddWithValue("@password", hashedPassword);
                    cmd.Parameters.AddWithValue("@email", email);
                    cmd.Parameters.AddWithValue("@question", recoveryQuestion);
                    cmd.Parameters.AddWithValue("@answer", hashedAnswer);

                    cmd.ExecuteNonQuery();
                }
            }

            MessageBox.Show("Doctor account created successfully! Please log in.");
            Application.Restart();
        }

        private void btnConfirmRecovery_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text;
            string recoveryQuestion = cmbRecoveryQuestion.SelectedItem.ToString();
            string recoveryAnswer = txtRecoveryAnswer.Text;
            string newPassword = txtNewPassword.Text;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT recovery_answer FROM Users WHERE email=@email AND recovery_question=@question";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@email", email);
                    cmd.Parameters.AddWithValue("@question", recoveryQuestion);
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        string storedAnswerHash = reader["recovery_answer"].ToString();
                        reader.Close();

                        if (BCrypt.Net.BCrypt.Verify(recoveryAnswer, storedAnswerHash))
                        {
                            string hashedNewPassword = BCrypt.Net.BCrypt.HashPassword(newPassword);
                            string updateQuery = "UPDATE Users SET password_hash=@password WHERE email=@email";

                            using (SqlCommand updateCmd = new SqlCommand(updateQuery, conn))
                            {
                                updateCmd.Parameters.AddWithValue("@password", hashedNewPassword);
                                updateCmd.Parameters.AddWithValue("@email", email);
                                updateCmd.ExecuteNonQuery();
                            }

                            MessageBox.Show("Password successfully reset! You can now log in.");
                        }
                        else
                        {
                            MessageBox.Show("Incorrect recovery answer.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("No account found with the provided email and security question.");
                    }
                }
            }
        }
    }
}
